from __future__ import annotations

import os
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from typing import Literal

from fastapi import Depends, FastAPI, HTTPException, Query, Response
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy import func, select, text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from .database import make_engine, sessions
from .models import Task


class TaskInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    title: str = Field(min_length=1, max_length=160)

    @field_validator("title")
    @classmethod
    def trim(cls, value):
        value = value.strip()
        if not value:
            raise ValueError("Enter a task title.")
        return value


class TaskUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    status: Literal["todo", "doing", "done"]


class TaskView(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    title: str
    status: str
    created_at: datetime


def create_app(engine=None):
    owned_engine = engine is None

    @asynccontextmanager
    async def lifespan(app):
        app.state.engine = engine if engine is not None else make_engine()
        app.state.sessions = sessions(app.state.engine)
        yield
        if owned_engine:
            app.state.engine.dispose()

    app = FastAPI(title="Omnix Launchboard demo", version="1.0.0", lifespan=lifespan, docs_url=None, redoc_url=None)

    def get_db():
        with app.state.sessions() as session:
            yield session

    @app.exception_handler(SQLAlchemyError)
    async def database_error(request, exc):
        return JSONResponse(status_code=503, content={"detail": "Database unavailable. Check the service logs and configuration."})

    @app.middleware("http")
    async def response_headers(request, call_next):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; object-src 'none'; frame-ancestors 'none'; base-uri 'self'"
        if request.url.path.startswith(("/api/", "/health/")):
            response.headers["Cache-Control"] = "no-store"
        return response

    @app.get("/health/live")
    def live():
        return {"status": "alive"}

    @app.get("/health/ready")
    def ready(db: Session = Depends(get_db)):
        db.execute(text("SELECT 1"))
        db.execute(select(Task.id).limit(1))
        return {"status": "ready", "database": "connected", "version": os.getenv("APP_VERSION", "local")}

    @app.get("/api/deployment")
    def deployment():
        return {"application": "Launchboard", "environment": os.getenv("APP_ENVIRONMENT", "development"),
                "version": os.getenv("APP_VERSION", "local"), "authentication": "demo-no-login"}

    @app.get("/api/tasks", response_model=list[TaskView])
    def list_tasks(limit: int = Query(100, ge=1, le=100), offset: int = Query(0, ge=0), db: Session = Depends(get_db)):
        return list(db.scalars(select(Task).order_by(Task.id.desc()).offset(offset).limit(limit)))

    @app.get("/api/summary")
    def summary(db: Session = Depends(get_db)):
        counts = {status: count for status, count in db.execute(select(Task.status, func.count()).group_by(Task.status))}
        return {status: counts.get(status, 0) for status in ("todo", "doing", "done")}

    @app.post("/api/tasks", response_model=TaskView, status_code=201)
    def create_task(payload: TaskInput, db: Session = Depends(get_db)):
        task = Task(title=payload.title)
        db.add(task)
        db.commit()
        return task

    @app.patch("/api/tasks/{task_id}", response_model=TaskView)
    def update_task(task_id: int, payload: TaskUpdate, db: Session = Depends(get_db)):
        task = db.get(Task, task_id)
        if task is None:
            raise HTTPException(404, "Task not found")
        task.status = payload.status
        db.commit()
        return task

    @app.delete("/api/tasks/{task_id}", status_code=204)
    def delete_task(task_id: int, db: Session = Depends(get_db)):
        task = db.get(Task, task_id)
        if task is None:
            raise HTTPException(404, "Task not found")
        db.delete(task)
        db.commit()
        return Response(status_code=204)

    app.mount("/", StaticFiles(directory=Path(__file__).resolve().parents[1] / "frontend", html=True), name="frontend")
    return app


app = create_app()
