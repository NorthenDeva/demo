"""Omnix deployment demonstration application."""
