"""Initial additive schema migration; run before service startup, never on GET."""
from .database import Base, make_engine
from . import models  # noqa: F401


def migrate(engine):
    # Demo v1 only creates its own table. Future changes need versioned migrations.
    Base.metadata.create_all(engine)


if __name__ == "__main__":
    engine = make_engine()
    try:
        migrate(engine)
    finally:
        engine.dispose()
    print("Demo schema migration completed.")
