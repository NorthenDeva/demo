from __future__ import annotations

import os
from pathlib import Path

from sqlalchemy import URL, create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker


class Base(DeclarativeBase):
    pass


def database_url():
    direct = os.getenv("DATABASE_URL")
    if direct:
        if not direct.startswith("postgresql+psycopg://"):
            raise ValueError("DATABASE_URL must use postgresql+psycopg://")
        return direct
    password_path = os.getenv("DATABASE_PASSWORD_FILE")
    if not password_path:
        raise ValueError("Configure DATABASE_URL or DATABASE_PASSWORD_FILE; no default credentials are used.")
    password = Path(password_path).read_text().strip()
    if len(password) < 24:
        raise ValueError("Database password must contain at least 24 characters.")
    return URL.create("postgresql+psycopg", username=os.getenv("DATABASE_USER", "demo"),
                      password=password, host=os.getenv("DATABASE_HOST", "db"),
                      port=int(os.getenv("DATABASE_PORT", "5432")), database=os.getenv("DATABASE_NAME", "demo"))


def make_engine(url=None):
    return create_engine(url if url is not None else database_url(), pool_pre_ping=True, hide_parameters=True)


def sessions(engine):
    return sessionmaker(bind=engine, expire_on_commit=False)
