"""Generate a local-only database password without displaying or replacing it."""
import os
from pathlib import Path
import secrets

root = Path(__file__).resolve().parents[1]
path = root / ".var" / "database_password"
path.parent.mkdir(mode=0o700, exist_ok=True)
try:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
except FileExistsError:
    print("Existing local database password preserved.")
else:
    with os.fdopen(fd, "w") as stream:
        stream.write(secrets.token_urlsafe(36))
    path.chmod(0o444)  # Container UID can read its mounted secret; parent remains private (0700).
    print("Local database password created in ignored .var/database_password.")
