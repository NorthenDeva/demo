"""Exercise a running demo with real PostgreSQL; removes only its own test task."""
import argparse
import json
import urllib.error
import urllib.request
import uuid
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url', default='http://127.0.0.1:18080')
    args = parser.parse_args()
    base = args.url.rstrip('/')

    def request(path, method='GET', payload=None):
        data = json.dumps(payload).encode() if payload is not None else None
        req = urllib.request.Request(base + path, data=data, method=method, headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(req, timeout=10) as response:
            body = response.read()
            return response.status, json.loads(body) if body else None

    deadline = time.monotonic() + 30
    while True:
        try:
            status, health = request('/health/ready')
            assert status == 200 and health['database'] == 'connected'
            break
        except (urllib.error.URLError, ConnectionError, TimeoutError):
            if time.monotonic() >= deadline:
                raise RuntimeError('Demo did not become ready within 30 seconds.') from None
            time.sleep(0.5)
    _, task = request('/api/tasks', 'POST', {'title': 'Smoke test ' + uuid.uuid4().hex[:12]})
    try:
        _, updated = request('/api/tasks/' + str(task['id']), 'PATCH', {'status': 'done'})
        assert updated['status'] == 'done'
        _, listed = request('/api/tasks')
        assert any(t['id'] == task['id'] and t['status'] == 'done' for t in listed)
        _, summary = request('/api/summary')
        assert summary['done'] >= 1
    finally:
        request('/api/tasks/' + str(task['id']), 'DELETE')
    print(json.dumps({'status': 'passed', 'checks': ['database readiness', 'create', 'update', 'list', 'summary', 'delete']}))


if __name__ == '__main__':
    main()
