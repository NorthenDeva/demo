"""Create a source release for the reviewed build stage; excludes all local secrets."""
from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parents[1]
output = root / 'dist'
output.mkdir(exist_ok=True)
archive = output / 'launchboard-source.zip'
files = [root / name for name in ('requirements.txt', 'requirements.lock', 'pyproject.toml', '.python-version', 'omnix-deploy.json')]
for directory in ('demo', 'frontend'):
    files.extend(p for p in (root / directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as release:
    for path in sorted(files):
        if path.is_symlink():
            raise ValueError('Release files must not be symlinks.')
        release.write(path, path.relative_to(root))
manifest = {'artifact': archive.name, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'kind': 'source-requires-build', 'files': len(files)}
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest))
