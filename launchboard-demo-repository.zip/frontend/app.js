const byId = (id) => document.getElementById(id);
const labels = {todo: 'To do', doing: 'In progress', done: 'Done'};
let loading = false;
function message(text, error = false) {
  byId('message').textContent = text;
  byId('message').classList.toggle('error', error);
}
async function api(path, options = {}) {
  const response = await fetch(path, {headers: {'Content-Type': 'application/json'}, ...options});
  if (!response.ok) throw new Error(`Request failed (${response.status}). Check API and database readiness.`);
  return response.status === 204 ? null : response.json();
}
function renderTask(task) {
  const card = document.createElement('article'); card.className = 'task';
  const title = document.createElement('p'); title.textContent = task.title;
  const controls = document.createElement('div'); controls.className = 'task-controls';
  const select = document.createElement('select'); select.setAttribute('aria-label', `Status for ${task.title}`);
  for (const [value, label] of Object.entries(labels)) {
    const option = document.createElement('option'); option.value = value; option.textContent = label; select.append(option);
  }
  select.value = task.status;
  select.addEventListener('change', async () => {
    select.disabled = true;
    try { await api(`/api/tasks/${task.id}`, {method: 'PATCH', body: JSON.stringify({status: select.value})}); await refresh(); }
    catch (error) { select.value = task.status; message(error.message, true); }
    finally { select.disabled = false; }
  });
  const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'delete'; remove.textContent = '×'; remove.setAttribute('aria-label', `Delete ${task.title}`);
  remove.addEventListener('click', async () => {
    remove.disabled = true;
    try { await api(`/api/tasks/${task.id}`, {method: 'DELETE'}); await refresh(); message('Task deleted.'); }
    catch (error) { message(error.message, true); } finally { remove.disabled = false; }
  });
  controls.append(select, remove); card.append(title, controls); return card;
}
async function refresh() {
  if (loading) return;
  loading = true; byId('refresh').disabled = true;
  try {
    const [tasks, summary, deployment, health] = await Promise.all([api('/api/tasks'), api('/api/summary'), api('/api/deployment'), api('/health/ready')]);
    byId('health').textContent = health.status === 'ready' ? '● Application ready' : 'Readiness unavailable';
    byId('health').classList.remove('error'); byId('version').textContent = `Release: ${deployment.version}`;
    byId('total').textContent = summary.todo + summary.doing + summary.done;
    byId('doing-count').textContent = summary.doing; byId('done-count').textContent = summary.done;
    for (const status of Object.keys(labels)) {
      const container = byId(`${status}-tasks`); container.replaceChildren();
      const filtered = tasks.filter((task) => task.status === status);
      byId(`${status}-badge`).textContent = summary[status];
      if (!filtered.length) {const empty = document.createElement('p'); empty.className = 'empty'; empty.textContent = status === 'todo' ? 'Your next idea starts here.' : 'Nothing here yet.'; container.append(empty);}
      for (const task of filtered) container.append(renderTask(task));
    }
  } catch (error) { byId('health').textContent = 'Connection needs attention'; byId('health').classList.add('error'); message(error.message, true); }
  finally {loading = false; byId('refresh').disabled = false;}
}
byId('task-form').addEventListener('submit', async (event) => {
  event.preventDefault(); const title = byId('task-title').value.trim(); if (!title) return;
  byId('add-task').disabled = true;
  try {await api('/api/tasks', {method: 'POST', body: JSON.stringify({title})}); byId('task-title').value = ''; await refresh(); message('Task saved to the database.');}
  catch (error) {message(error.message, true);} finally {byId('add-task').disabled = false;}
});
byId('refresh').addEventListener('click', () => {message(''); refresh();});
refresh();
