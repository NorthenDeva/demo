from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool
import pytest

from demo.main import create_app
from demo.migrate import migrate


@pytest.fixture
def engine():
    engine = create_engine('sqlite://', connect_args={'check_same_thread': False}, poolclass=StaticPool)
    yield engine
    engine.dispose()


@pytest.fixture
def client(engine):
    migrate(engine)
    with TestClient(create_app(engine)) as client:
        yield client


def test_complete_task_lifecycle_and_frontend(client):
    page = client.get('/')
    assert page.status_code == 200 and 'Launchboard' in page.text
    assert 'frame-ancestors' in page.headers['content-security-policy']
    assert client.get('/health/ready').json()['database'] == 'connected'
    assert client.get('/api/summary').json() == {'todo': 0, 'doing': 0, 'done': 0}
    created = client.post('/api/tasks', json={'title': ' Verify deployment '})
    assert created.status_code == 201
    task = created.json()
    assert task['title'] == 'Verify deployment'
    assert client.get('/api/tasks').json()[0]['id'] == task['id']
    assert client.patch(f"/api/tasks/{task['id']}", json={'status': 'done'}).status_code == 200
    assert client.get('/api/summary').json()['done'] == 1
    assert client.delete(f"/api/tasks/{task['id']}").status_code == 204
    assert client.get('/api/tasks').json() == []


def test_ready_fails_until_schema_exists_but_liveness_works(engine):
    with TestClient(create_app(engine)) as client:
        assert client.get('/health/live').status_code == 200
        response = client.get('/health/ready')
        assert response.status_code == 503
        assert 'SELECT' not in response.text


def test_restart_preserves_data_and_migration_is_repeatable(engine):
    migrate(engine)
    with TestClient(create_app(engine)) as first:
        first.post('/api/tasks', json={'title': 'Persistent task'})
    migrate(engine)
    with TestClient(create_app(engine)) as second:
        assert second.get('/api/tasks').json()[0]['title'] == 'Persistent task'


@pytest.mark.parametrize('title', ['', '   ', 'x' * 161])
def test_rejects_invalid_title(client, title):
    assert client.post('/api/tasks', json={'title': title}).status_code == 422


def test_invalid_status_missing_task_and_bounded_list(client):
    assert client.patch('/api/tasks/123', json={'status': 'done'}).status_code == 404
    assert client.patch('/api/tasks/123', json={'status': 'unknown'}).status_code == 422
    assert client.get('/api/tasks?limit=101').status_code == 422
    assert client.post('/api/tasks', json={'title': 'x', 'status': 'done'}).status_code == 422


def test_metadata_never_returns_database_credentials(client, monkeypatch):
    monkeypatch.setenv('DATABASE_URL', 'postgresql+psycopg://private:secret@db/private')
    assert 'secret' not in client.get('/api/deployment').text
