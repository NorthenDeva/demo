# Launchboard — shared-dev deployment demo

A small, working application for testing application onboarding: a task-board frontend, a FastAPI backend, and PostgreSQL persistence. Create tasks, change their status, delete them, and check API/database readiness.

The frontend uses plain HTML/CSS/JavaScript and is served by FastAPI on the same origin. No Node build or CORS setup is required. The complete application can eventually run as one systemd service behind the existing shared Nginx/ALB; the database will be its dedicated database on existing RDS. Local Compose is a test environment, not the future AWS deployment architecture.

## Run locally

Requirements: Docker Engine/Desktop with Compose v2 and Python 3.12 for the setup script.

From this directory:

```bash
python3 scripts/setup_local.py
docker compose up --build -d
```

Open http://localhost:18080. Only loopback is exposed; PostgreSQL has no published host port. A local password is generated under the ignored `.var/` directory and mounted only into the services that need it. The parent directory is private; the mounted file is readable by the non-root app user. This local development secret file is not the proposed AWS secret-delivery mechanism.

Check status and logs:

```bash
docker compose ps
docker compose logs --tail=100 app migrate
```

Use a different local port if necessary:

```bash
DEMO_PORT=18081 docker compose up --build -d
```

Stop containers while retaining demo data:

```bash
docker compose down
```

For an intentional full local reset only, `docker compose down --volumes` deletes this demo project's database. Do not delete/rotate the local password while retaining the database volume: PostgreSQL initializes it only on first creation.

## What to test

1. Open the page; application status should become ready.
2. Add a task; it should appear in To do.
3. Move it to In progress and then Done.
4. Refresh the page; the task should remain.
5. Run `docker compose restart app`; refresh again and verify persistence.
6. Delete the task.
7. Open `/health/ready` for database/schema readiness and `/openapi.json` for the API contract.

This demo intentionally has no login. Use sample data and keep it on loopback or an access-controlled dev environment. It is not a production application.

## Repository layout

- `frontend/`: static browser UI, no external CDN or JavaScript dependencies.
- `demo/`: FastAPI routes, SQLAlchemy model and additive v1 schema migration.
- `tests/`: API, validation, readiness and restart-persistence tests.
- `requirements.lock`: resolved runtime dependencies validated in the container.
- `Dockerfile`, `compose.yaml`: local app/database/migration setup.
- `omnix-deploy.json`, `.python-version`: explicit onboarding contract.
- `.github/workflows/ci.yml`: tests and source packaging on pushes to main/development and pull requests. **No AWS deployment is connected yet.**

## Upload to GitHub

Upload this directory's contents as the **root of a new repository**, not the whole Omnix checkout. Include hidden `.github/`, `.gitignore`, `.python-version` and `.env.example`. Exclude `.var/`, `.env`, virtual environments, caches and `dist/`.

Recommended: extract the provided `launchboard-demo-repository.zip` to a new local directory and run the following there. Replace `YOUR_ORG` with your account/organization after creating an empty repository named `launchboard-demo` in GitHub.

```bash
git init -b development
git add .
git status --short
git commit -m "Add Launchboard full-stack deployment demo"
git remote add origin https://github.com/YOUR_ORG/launchboard-demo.git
git push -u origin development
```

Use your normal GitHub authentication; do not add a token to the remote URL. The CI workflow will test and package the application. It will not deploy until we implement and connect the deployment runtime.

## Run tests without Docker

```bash
python3.12 -m venv .venv
. .venv/bin/activate
pip install -r requirements-dev.txt
python -m pytest -q
```

API unit tests use isolated SQLite, without using your PostgreSQL credentials. The container smoke test validates actual PostgreSQL separately.

## AWS deployment contract for the next phase

- Runtime: Python 3.12, with dependencies installed from `requirements.lock` in an isolated builder matching the host.
- Database: a dedicated PostgreSQL database and restricted app login. The local Compose database superuser is for the isolated local demo only; do not reuse that privilege model on RDS.
- Runtime secret: `DATABASE_URL`, formatted `postgresql+psycopg://...`; values are supplied securely by the deployment runtime.
- Migration: `python -m demo.migrate`; run as the app's authorized migration identity before activation. This v1 migration only creates the demo table if missing; it is not a general schema-upgrade engine.
- Start: `python -m uvicorn demo.main:app --host 127.0.0.1 --port <reserved-port> --no-proxy-headers`.
- Readiness: `/health/ready`; liveness: `/health/live`.
- Release label: `APP_VERSION=<commit SHA>`, shown by UI and readiness response.
- Static frontend and API share the app port. Nginx proxies to that port; the ALB terminates HTTPS.
- The app does not need media uploads. The general use case may create its private bucket, but this demo does not claim S3 browser-upload coverage.

`python scripts/package_release.py` creates a secret-free **source** ZIP, not a fully built runtime artifact. The future builder must install dependencies and produce a verified release before staging it on the server.
